import { Router } from "express";
import { db } from "@workspace/db";
import { bloodStockTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const stock = await db.select().from(bloodStockTable).orderBy(bloodStockTable.blood_group);
    const mapped = stock.map((s) => ({
      ...s,
      updated_at: s.updated_at?.toISOString() ?? new Date().toISOString(),
    }));
    res.json(mapped);
  } catch (err) {
    req.log.error({ err }, "Failed to list blood stock");
    res.status(500).json({ error: "Internal server error", message: "Failed to list blood stock" });
  }
});

router.get("/:blood_group", async (req, res) => {
  try {
    const bloodGroup = req.params.blood_group;
    const [stock] = await db.select().from(bloodStockTable).where(eq(bloodStockTable.blood_group, bloodGroup));
    if (!stock) {
      return res.status(404).json({ error: "Not found", message: "Blood group not found" });
    }
    res.json({
      ...stock,
      updated_at: stock.updated_at?.toISOString() ?? new Date().toISOString(),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get blood stock");
    res.status(500).json({ error: "Internal server error", message: "Failed to get blood stock" });
  }
});

export default router;
